from vpython import *
#Web VPython 3.2

gDvsR = graph( title="b/m vs Optimal Angle", xtitle="b/m (m<sup>-1</sup>)", ytitle="Optimal Angle (degrees)")

dVsR = gdots(graph=gDvsR)

t = 0
dt = 0.01

gravity = vec(0,-9.8,0)

ranges = []
angles = []

startMag = 40
drag = 0

def startForce(force, angle):
    return vec(force*cos(angle), force*sin(angle), 0)

def a(vel, drag):
    global gravity
    return gravity - drag * (vel.mag)**2 * vel.hat


def rk2(vel, drag):
    k1 = a(vel, drag) * dt
    k2 = a(vel + k1/2, drag) * dt
    return vel + k2



while drag < 1:
    ranges = []
    angles = []
    
    for angle in range(1, 46, 1):
        started = False
        pos = vec(0,0,0)
        vel = startForce(startMag, radians(angle))
        while pos.y >= 0 or not started:
            rate(1000/dt)
            vel = rk2(vel, drag)
            pos += vel * dt
            started = True
        ranges += [abs(pos.x)]
        angles += [angle]
        
    bestRange = max(ranges)
    bestIndex = ranges.index(bestRange)
    dVsR.plot(drag, angles[bestIndex])
    drag += 0.1