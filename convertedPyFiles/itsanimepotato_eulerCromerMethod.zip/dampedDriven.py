from vpython import *
#Web VPython 3.2

scene.userzoom = False

ball = sphere(pos=vector(0,0,0), radius=0.3, color=color.yellow)
ball.mass = 60
ball.vel = vector(0,0,0)

wall = box(pos=vector(-3,0,0), height=3, length=0.1, texture=textures.wood)

spring = helix(pos=wall.pos, axis=ball.pos-wall.pos, coils=20, radius=0.2)
spring.k = 240
spring.L0 = 3

wd = 1.8
b = 0.1*2*sqrt(spring.k*ball.mass)

t = 0
dt = 0.01

vpGraph = graph(title="Phase Space: Velocity vs Position", xtitle="Position", ytitle="Velocity")
phaseCurve = gcurve(graph=vpGraph, color=color.blue)

posGraph = graph(title="Position vs Time", xtitle="Time", ytitle="Position")
ballCurve = gcurve(graph=posGraph, color=color.blue, label="Ball")
wallCurve = gcurve(graph=posGraph, color=color.red, label="Wall")

def wallPos(t):
    return -3 + sin(wd*t)

def springForce(ball_pos, wall_pos):
    equilPos = wall_pos + vector(spring.L0,0,0)
    return -spring.k*(ball_pos - equilPos)

def dampingForce(vel):
    return -b*vel

while True:
    rate(1000)
    t += dt
    wall.pos.x = wallPos(t)
    F_spring = springForce(ball.pos, wall.pos)
    F_damping = dampingForce(ball.vel)
    ball.acc = (F_spring + F_damping)/ball.mass
    ball.vel += ball.acc*dt
    ball.pos += ball.vel*dt
    spring.pos = wall.pos
    spring.axis = ball.pos - wall.pos
    phaseCurve.plot(ball.pos.x, ball.vel.x)
    ballCurve.plot(t, ball.pos.x)
    wallCurve.plot(t, wall.pos.x)