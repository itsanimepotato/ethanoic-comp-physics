from vpython import *
#Web VPython 3.2


# Define a function called cooling that takes temperature T as an argument
def cooling(temp):
# Return the rate of temperature change
    return (20 - temp) * 0.2

# make a list of starting temperatures from -100 C to + 40 C in steps of 10 C
startTemp = []
for i in range(-100, 50, 10):
    startTemp.append(i)
    
print(startTemp)


# define a time step deltat
dt=0.1

# define a run time for the simulation tMax
tMax=10

# make a graphing canvas to plot temperature vs time
tTCanvas = graph(title="Temp (Celsius) vs. Time (sec)", xtitle="Time", ytitle="Temp")

# iterate through every item in your list
for i in range(len(startTemp)):
     # make a gcurve and plot the starting temperature
     tTDots = gdots(graph=tTCanvas)
     temp = startTemp[i]
     
     tTDots.plot(0,temp)
     # iterate from time deltat to tMax in steps of deltat
     for t in range(0,tMax,dt):
     # assign the temp to temp + cooling(temp) * deltat
        temp = temp + cooling(temp) * dt
     # plot the new temperature
        tTDots.plot(t, temp)
        t += dt

# things to try playing with: 
# increase and decrease deltat
# Change the cooling parameter from 0.2 to something higher or lower. 
# Change the environmental temperature to something other than 20
# Do any of these change the end behavior? The short term behavior?

