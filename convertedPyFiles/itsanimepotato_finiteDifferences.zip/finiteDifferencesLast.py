from vpython import *
#Web VPython 3.2

tMax = 0
tMin = 25

totalTime = tMax - tMin
dt = totalTime/1000

def p(t):
    return 3*cos(t)

def a(t):
    sum = (p(t+dt) + p(t-dt) - (2*p(t)))
    return sum/(dt*dt)

positionGraph = graph(title="Position vs. Time", xtitle = "Time", ytitle="Position")
positionCurve = gcurve(graph=positionGraph, color=color.blue)


accelGraph = graph(title="Acceleration vs. Time", xtitle="Time", ytitle="Acceleration")
accelCurve = gcurve(graph=accelGraph, color=color.red)

for t in range(tMin, tMax, dt):
    positionCurve.plot(t,p(t))
    accelCurve.plot(t,a(t))
    
    




