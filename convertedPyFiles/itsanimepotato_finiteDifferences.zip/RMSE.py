from vpython import *
#Web VPython 3.2

tMin = -1
tMax = 2.5

rmseGraph = graph(title="RMSE vs. Time")
rmseCurve = curve()

totalTime = tMax - tMin
dt = totalTime/67

def p(t):
    total = (0.8*t*t*t*t)+(-2.2*t*t*t)+(1.5*t)+1
    return total

def v(t):
    total = (3.2*t*t*t)+(-6.6*t*t)+1.5
    return total
    
    
def vC(t):
    total = p(t+dt) - p(t-dt)
    total = total/(dt*2)
    return total

def centralDiff(t,dt):
    return((p(t+dt)-p(t))/dt)

def forwardDiff(t,dt):
    return((p(t+dt)-p(t))/dt)

rmse_central = gcurve(graph = rmseGraph, color=color.blue, label="central")
#for each time step i, we need deviance
def centralDiffSummation(dt):
    numStepsCentral = 0
    centralDiffSum = 0
    timeStep = tMin
    while timeStep <= tMax:
        deviance = (v(timeStep)-centralDiff(timeStep, dt))
        centralDiffSum+= (deviance**2)
        timeStep += 0.001
        numStepsCentral += 1
    return sqrt(centralDiffSum/numStepsCentral)

dt = 0.001
while dt <= 0.05:
    rmse_central.plot(dt, centralDiffSummation(dt))
    dt += 0.001


rmse_forward = gcurve(graph = rmseGraph, color = color.red, label="forward")
def forwardDiffSummation(dt):
    numStepsForward = 0
    forwardDiffSum = 0
    timeStep = tMin
    while timeStep <= tMax:
        deviance = (p(timeStep)-forwardDiff(timeStep, dt))
        forwardDiffSum+= (deviance**2)
        timeStep += 0.001
        numStepsForward += 1
    return sqrt(forwardDiffSum/numStepsForward)

dt = 0.001
while dt <= 0.05:
    rmse_forward.plot(dt, forwardDiffSummation(dt))
    dt += 0.001

rmseGraph = graph(title="Velocity vs. Time", xtitle="Time", ytitle="Velocity")

rmseCentralCurve = gcurve(graph=rmseGraph, color=color.blue, label="Central Difference RMSE")

rmseForwardCurve = gcurve(graph=rmseGraph, color=color.red, label="Forward Difference RMSE")

for t in range(tMin, tMax, 0.002):
    rmseCentralCurve.plot(t,vC(t))
    rmseForwardCurve.plot(t,vC(t))


