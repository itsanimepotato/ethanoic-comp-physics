from vpython import *
#Web VPython 3.2
"""README:
This is a discrete vector field simulation. The only real field that is an option is gravity. But there are also non-real fields. 
The program works by computing a vector field at a lot of points, this method is thus O(n) where n is the number of objects. Granted the constant is pretty big, so the only purpose in this example is having a nice looking field.
The vector field is then used to find the forces acting on each individual particle. 

Aside from the gravity field, there are two more fields that can be simulated using this program.
The Cool Swirly Field is an altered version of a magnetic field exerted by moving particles, but it's been compressed down to 2 dimensions and so is not actually how magnetic fields work. 
The Carousel features an object that exerts a circular force around itself along with multiple gravity objects. 

The number of subdivisions in the field can be altered, the total number of segments is subdivisions^2

There is equipotential line coloring in this program. Since the field is not continuous in any way, it works the same way photoshop's bucket fill tool does, and the tolerances can be adjusted.
There are two types of equipotential line colorings (although they are hard to distinguish at runtime): 
The iterated field tolerance starts at top left and iterates down to the bottom right. There are 16 of these lines. 
The mean object position field line is self explanatory, it starts at the average position of every object. 

Since this field is discrete and non-continuous, conservative properties can often not apply. To estimate the error at any given point you can use the closed curve integral button. The output from it should be close to 0.
Note that for non gravity fields it is completely meaningless. 

There are two graphs: one to track the total kinetic energy in the system and one to track the distance from the center.

The field is not infinite and there are walls, to prevent particle accelerators collisions with these walls are not elastic. 


https://www.glowscript.org/#/user/agaziiantc60/folder/finalProject/program/Agravmain

"""



DCvsT = graph(title="Distance from center vs. Time", xtitle="Time", ytitle="Distance")
DCvsTC = []
    
SKEvsT = graph(title="Total kinetic energy vs. Time", xtitle="Time", ytitle="KE (J)")
kePlot = gcurve(); 

class Vector2:
    def __init__(self, x, y):
        self.x = x;
        self.y = y;
    def __add__(self, other):
        self.x += other.x;
        self.y += other.y; 
        return self;
    def __subtract__(self, other):
        self.x -= other.x;
        self.y -= other.y;
        return self;  

    def __multiply__(self, other):
        self.x *= other;
        self.y *= other;
        return self;
    def setX(self, x):
        self.x = x;
    def setY(self, y):
        self.y = y;
    def clone(self):
        return Vector2(self.x, self.y);
    def magsq(self):
        return self.x*self.x + self.y*self.y;
    def mag(self):
        return sqrt(self.x*self.x + self.y*self.y);
    def distsq(self, other):
        return (self.x-other.x)*(self.x-other.x) + (self.y-other.y)*(self.y-other.y);
    def toString(self):
        return f"<{self.x}, {self.y}>"

class EquipotentialLine:
    def __init__(self, col):
        #self.curve = curve(radius=fieldDA/3, color=col); 
        self.color = col;
    def initField(self, field):
        global field;
        for x in range(0, fieldCount):
            for y in range(0, fieldCount):
                field[x][y].flag = False;
                field[x][y].color = vec(1,1,1); 
    def greedyAdd(self, x, y, tol, prevVal):
        global field;
        #print(x, y, field[x][y].flag);
        if(x < 0 or y < 0 or x >= fieldCount or y >= fieldCount):
            #print("NOT ADDING", x, y);
            return;
        else:
            if(not field[x][y].flag):
                #print("a");
                if(abs((field[x][y].pos.y-prevVal) / prevVal) < tol):
                    #print("b");
                    #rate(100);
                    #self.curve.append(vec(x*fieldDA, 0, y*fieldDA));
                    field[x][y].flag = True;
                    field[x][y].color = self.color;
                    self.greedyAdd(x+1, y, tol, prevVal);
                    self.greedyAdd(x-1, y, tol, prevVal); 
                    self.greedyAdd(x, y+1, tol, prevVal); 
                    self.greedyAdd(x, y-1, tol, prevVal); #not a fan of the recursion but it already will barely run so idc tbh 
            
    def clear(self):
        self.curve.visible = False;
        self.curve = curve(color=self.curve.color); 

regTol = 0.09;
meanTol = 0.23;

def runFieldLines():
    if(doFieldLines):
        meanX = 0;
        meanY = 0;
        for o in Objects:
            meanX += o.getX()/len(Objects);
            meanY += o.getY()/len(Objects);
            
        larr[0].initField(field);
        for i in range(1, len(larr)):
            l = floor(i * (fieldCount / len(larr)) * 1)
            #box(pos=vec(l*fieldDA, 0, l*fieldDA), size=vec(1,1,1)*fieldDA);
            larr[i].greedyAdd(l, l, regTol, field[l][l].pos.y);
        meanX = round(meanX);
        meanY = round(meanY);
        larr[0].greedyAdd(meanX, meanY, meanTol, field[meanX][meanY].pos.y);

fieldCount = 32; 
fieldWidth = 8e11; #do not ask what the units are
fieldDA = fieldWidth / (fieldCount-1); 
downConstant = log10(fieldDA);
fieldExponent = 0; 
field = [[arrow(pos=vec(y*fieldDA, 0, x*fieldDA), flag=False) for x in range(0, fieldCount)] for y in range(0, fieldCount)];

def stretch(evt):
    global fieldCount;
    global fieldDA;
    global downConstant;
    global field;
    global fieldWidth;
    if(evt.id is "fieldCount"):
        for x in range(0, fieldCount):
            for y in range(0, fieldCount):
                field[x][y].visible = False;
        fieldCount = evt.value;
        fcWT.text='Field resolution: {0} subdivisions'.format(evt.value)
        fieldDA = fieldWidth / (fieldCount-1); 
        downConstant = log10(fieldDA);
        field = [[arrow(pos=vec(y*fieldDA, 0, x*fieldDA), flag=False) for x in range(0, fieldCount)] for y in range(0, fieldCount)]; #a pretty notable issue: the field is larger at higher subdivisions. Idk why.
        zeroField(field);
        for o in Objects:
            o.impactField(field, v2pos, gravityField);
        normalizeField(field);
        #print(fieldWidth, fieldCount, fieldDA);
        #print(fieldCount * fieldDA);
        #print(field[fieldCount-1][fieldCount-1].pos, field[fieldCount-1][fieldCount-1].pos+vec(1,0,1)*fieldDA);
        #marker.pos = vec(1,0,1)*fieldWidth;
        #marker.size=vec(1,1,1)*fieldDA;
        
        
fcSlider = slider(bind=stretch, max=80, min=16, step=1, value=fieldCount, id="fieldCount");
fcWT = wtext(text='Field resolution: {0} subdivisions'.format(fcSlider.value))

def toggleRunning(b):
    global running;
    running = not running;
    if(running):
        b.text = "Click to pause the simulation";
    else:
        b.text = "Click to continue the simulation"; 

def toggleLines(b):
    global doFieldLines; 
    global field;
    doFieldLines = not doFieldLines;
    if(doFieldLines):
        b.text = "Click to turn off the field lines";
        runFieldLines();
    else:
        b.text = "Click to re-enable the field lines"; 
        for x in range(0, fieldCount):
            for y in range(0, fieldCount):
                field[x][y].flag = False;
                field[x][y].color = vec(255,255,255); 

def regTolStretch(evt):
    global regTol; 
    if(evt.id is "regTol"):
        regTol = evt.value;
        regTolWT.text = 'Iterated field line tolerance: {:1.2f}'.format(regTol)
        runFieldLines();
def meanTolStretch(evt):
    global meanTol; 
    if(evt.id is "meanTol"):
        meanTol = evt.value;
        meanTolWT.text = 'Mean object position field line tolerance: {:1.2f}'.format(meanTol)
        runFieldLines();
def fieldScaleStretch(evt):
    global fieldExponent; 
    if(evt.id is "fieldExponent"):
        fieldExponent = evt.value;
        fieldScaleSliderWT.text = "Field line scale exponent: {:1.3f}".format(fieldExponent)
        runFieldLines();

scene.append_to_caption('\n\n')
menu(choices=['Choose a preset', 'Earth and the Sun', 'Binary system', 'Trinary system', 'Binary + Planet', 'Orbital ring', 'Syzygy', "Carousel", 'Random', "Cool swirly field (NOT GRAVITY)", "Cool swirly field 2 (NOT GRAVITY)"], index=0, bind=chooseSystem);
scene.append_to_caption('\n\n')
runButton = button(bind=toggleRunning, text="Click to start the simulation");
scene.append_to_caption('\n\n')
integralButton = button(bind=ccButton, text="Click to compute a closed curve integral around the field (aka measure error)");
scene.append_to_caption('\n\n')
runButton = button(bind=toggleLines, text="Click to enable equipotential coloring in the field");
scene.append_to_caption('\n\n')
regTolSlider = slider(bind=regTolStretch, max=1, min=0, step=0.01, value=regTol, id="regTol");
regTolWT = wtext(text='Iterated field line tolerance: {:1.2f}'.format(regTolSlider.value))
scene.append_to_caption('\n\n')
meanTolSlider = slider(bind=meanTolStretch, max=1, min=0, step=0.01, value=meanTol, id="meanTol");
meanTolWT = wtext(text='Mean object position field line tolerance: {:1.2f}'.format(meanTolSlider.value))
scene.append_to_caption('\n\n')
fieldScaleSlider = slider(bind=fieldScaleStretch, max=1, min=0, step=0.01, value=fieldExponent, id="fieldExponent");
fieldScaleSliderWT = wtext(text="Field line scale exponent: {:1.3f}".format(fieldScaleSlider.value));


G = 6.7e-11;
#G*=4; #not figuring out dimensions and its consequences...
#G=1;

def printField(field):
    for x in range(0, fieldCount):
        for y in range(0, fieldCount):
            str = (field[x][y].axis)
            print(str, end=" ");
        print();

EPSILON = 1e-5

def zeroPoint(field, x, y):
    field[x][y].axis = vec(0,0,0);
    field[x][y].pos.y = 0;

def zeroField(field):
    for x in range(0, fieldCount):
        for y in range(0, fieldCount):
            zeroPoint(field, x, y);


def gravityField(field, v2pos, vel, mass, mass2):
    for y in range(0, fieldCount):
        for x in range(0, fieldCount):
            p = vector(x*fieldDA, 0, y*fieldDA);
            #marker.pos = p;
            p.x -= v2pos.x;#*fieldDA;
            p.z -= v2pos.y;#*fieldDA;
            #marker.axis=-p;
            valMag = mag(p);
            #field[x][y].axis += -hat(p)*0.1; #-(fieldDA / (valMag)) * p ; #test jargon, this is not gravity. 
            if(valMag > fieldDA): #objects shouldnt impact themselves. this is relevant because of the field being discrete        
                field[x][y].axis += -p*(G*mass)/(valMag**2);
                field[x][y].pos.y -= (G*mass*fieldDA*downConstant)/(valMag**2);

def testField(field, v2pos, vel, mass, mass2):
    for y in range(0, fieldCount):
        for x in range(0, fieldCount):
            field[x][y].axis = vec(2*x, 0, 2*y) * fieldDA;

magnetConstant = 1e-7

def coolSwirlyField(field, v2pos, y, vel, mass, charge):
    for y in range(0, fieldCount):
        for x in range(0, fieldCount):
            p = vector(x*fieldDA, 0, y*fieldDA);
            #marker.pos = p;
            p.x -= v2pos.x;#*fieldDA;
            p.z -= v2pos.y;#*fieldDA;
            
            #marker.axis=-p;
            valMag = mag(p);
            crs = cross(vel, p+vec(0,y,0)); #yea so turns out computing a magnetic field with two dimensions is a pain so we just won't do that thumbs up
            if(valMag > fieldDA): #objects shouldnt impact themselves. this is relevant because of the field being discrete  
                force = magnetConstant * charge * crs / (valMag ** 2); 
                field[x][y].axis -= force;
                #field[x][y].pos.y -= (G*mass*fieldDA*downConstant)/(valMag**2);

def carouselField(field, v2pos, vel, mass, mass2):
    scaler = fieldDA/(pi);
    for y in range(0, fieldCount):
        for x in range(0, fieldCount):
            p = vector(x*fieldDA, 0, y*fieldDA);
            p.x -= v2pos.x;
            p.z -= v2pos.y;
            
            force = vec(p.z, 0, -p.x);
            field[x][y].axis += hat(force)*scaler;

def normalizeField(field):
    for y in range(0, fieldCount):
        for x in range(0, fieldCount):
            field[x][y].axis *= (mag(field[x][y].axis) ** fieldExponent); 
            if(mag(field[x][y].axis) > fieldDA):
                field[x][y].axis = hat(field[x][y].axis)*fieldDA



t = 0;
dt = 0.1; 


class body:
    def __init__(self, x, y, mass, dims, func, trail=False, mass2=0, fieldFunc=gravityField):
        #print(x, y, dims);
        self.obj = func(pos=vec(x, 0, y), size=vec(dims, dims, dims), make_trail=trail);
        self.obj.vel = vec(0,0,0);
        self.obj.acc = vec(0,0,0);
        self.obj.mass = mass;
        self.obj.mass2 = mass2; #this is for non-gravity things such as charge and whatnot
        self.function = fieldFunc;
    def applyForce(self, field):
        if(self.obj.pos.x > fieldWidth):
            self.obj.pos.x = fieldWidth-fieldDA; 
        elif(self.obj.pos.x < 0):
            self.obj.pos.x = fieldDA; 
        if(self.obj.pos.z > fieldWidth):
            self.obj.pos.z = fieldWidth-fieldDA; 
        elif(self.obj.pos.z < 0):
            self.obj.pos.z = fieldDA;
        
        ax = field[round(self.obj.pos.x/fieldDA)][round(self.obj.pos.z/fieldDA)];
        if(ax is not None):
            #self.obj.acc = (ax.axis/fieldDA) * -(ax.pos.y); 
            self.obj.acc = ax.axis;
            if(self.function is not gravityField):
                self.obj.acc *= self.obj.mass2 / self.obj.mass;
                
            self.obj.vel += self.obj.acc * dt / 2;
            self.obj.pos += self.obj.vel * dt;
            self.obj.vel += self.obj.acc * dt / 2;
        collisionFlag = False;
        if(self.obj.pos.x+self.obj.vel.x*dt >= fieldWidth-fieldDA or self.obj.pos.x+self.obj.vel.x*dt < fieldDA): 
            self.obj.vel.x *= -1; 
            collisionFlag = True;
        if(self.obj.pos.z+self.obj.vel.z*dt > fieldWidth-fieldDA or self.obj.pos.z+self.obj.vel.z*dt < fieldDA):
            self.obj.vel.z *= -1;
            collisionFlag = True;
        if(collisionFlag):
            self.obj.pos += self.obj.vel * 1.1 * dt;
            self.obj.vel *= 0.9
    def getX(self):
        return round(self.obj.pos.x/fieldDA);
    def getY(self):
        return round(self.obj.pos.z/fieldDA);
    def setVel(self, v):
        self.obj.vel = v;
    def setColor(self, c):
        self.obj.color = c;
    def impactField(self, field, v2):
        v2.x = self.obj.pos.x;
        v2.y = self.obj.pos.z;
        if(self.function is coolSwirlyField):
            self.function(field, v2, self.obj.pos.y, self.obj.vel, self.obj.mass, self.obj.mass2);
        else:
            self.function(field, v2, self.obj.vel, self.obj.mass, self.obj.mass2); 
    def dist(self, other):
        return self.obj.pos - other.obj.pos
    def moveTo(self, v):
        self.obj.pos = v;
    def getMass(self):
        return self.obj.mass;
            
scene.append_to_title("<h1>Multi body field forces simulation\n")
scene.append_to_title("""This is a discrete gravity field simulation. You can define the precision of the field using the field resolution slider
Due to being a discrete field, there will be inherent error in the simulation, you can measure said error via the closed curve integral button
There's also a few non-physics fields, those being the Cool Swirly Fields and the Carousel, although the Carousel still contains gravity objects""")

#obj = box(pos=vec(fieldWidth/2, fieldWidth/2, 0));

rate(60);
#printField(field); 

#floor = box(pos=vec(fieldWidth/2,0,fieldWidth/2), size=vec(fieldWidth, 0.1, fieldWidth), opacity=0.5);
#marker1 = arrow(size=vec(1,1,1)*fieldDA, color=color.yellow); 
#marker2 = arrow(size=vec(1,1,1), color=color.red); 

def ccButton():
    closedCurveIntegral(4); 

def closedCurveIntegral(rfactor=4):
    global running;
    runningCache = running;
    running = False;
    obj = body(fieldDA * fieldCount/2 + fieldWidth/8, fieldDA*fieldCount/2, 1, fieldDA*0.2, sphere, trail=False);
    obj.setColor(color.green);
    sum = 0;
    r = fieldCount * rfactor;
    #print(r);
    for i in range(0, fieldCount, 1):
        rate(r);
        circPos = vec(0, 0, fieldDA*i); 
        vel = vec(0, 0, 1);
        obj.moveTo(circPos); 
        obj.obj.make_trail=True;
        ax = field[round(obj.obj.pos.x/fieldDA)][round(obj.obj.pos.z/fieldDA)];
        sum += dot((ax.axis), hat(vel));
    for i in range(0, fieldCount, 1):
        rate(r);
        circPos = vec(fieldDA*i, 0, fieldWidth); 
        vel = vec(1, 0, 0);
        obj.moveTo(circPos); 
        obj.obj.make_trail=True;
        ax = field[round(obj.obj.pos.x/fieldDA)][round(obj.obj.pos.z/fieldDA)];
        sum += dot((ax.axis), hat(vel));
    for i in range(0, fieldCount, 1):
        rate(r);
        circPos = vec(fieldWidth, 0, fieldWidth-fieldDA*i); 
        vel = vec(0, 0, -1);
        obj.moveTo(circPos); 
        obj.obj.make_trail=True;
        ax = field[round(obj.obj.pos.x/fieldDA)][round(obj.obj.pos.z/fieldDA)];
        sum += dot((ax.axis), hat(vel));
    for i in range(0, fieldCount, 1):
        rate(r);
        circPos = vec(fieldWidth-fieldDA*i, 0, 0); 
        vel = vec(-1, 0, 0);
        obj.moveTo(circPos); 
        obj.obj.make_trail=True;
        ax = field[round(obj.obj.pos.x/fieldDA)][round(obj.obj.pos.z/fieldDA)];
        sum += dot((ax.axis), hat(vel));
    
        
    print("Closed curve integral of the field (N): ", f"{sum:.8f}");
    nf = 0;
    for x in range(0, fieldCount):
        for y in range(0, fieldCount):
            nf += mag(field[x][y].axis);
    nf /= (fieldCount**2); 
    ratio = (sum/nf)*100
    print("Closed curve integral % of the average field magnitude: ", f"{ratio:.8f}%"); 
    #print("The integral of the field / the mass of the objects*G (expected to be effectively 0): ");
    #for o in Objects:
    #    print(sum/o.obj.mass*G);  
    obj.obj.visible = False;
    obj.obj.clear_trail(); 
    running = runningCache;
    return sum;
    
    
Objects = [];
fieldFunction = gravityField;

def chooseSystem(m):
    global Objects;
    global fieldDA;
    global downConstant;
    global field;
    global fieldWidth;
    global fieldFunction;
    val = m.selected
    for o in Objects:
        o.obj.visible=False;
    Objects = [];
    global DCvsT, DCvsTC;
    DCvsT.delete()
    DCvsT = graph(title="Distance from center vs. Time", xtitle="Time", ytitle="Distance", fast=True, ymin=0)
    DCvsTC = []
    
    global SKEvsT, kePlot;
    SKEvsT.delete();
    SKEvsT = graph(title="Total kinetic energy vs. Time", xtitle="Time", ytitle="KE (J)")
    kePlot = gcurve(); 
    if(val == 'Earth and the Sun'):     
        #Earth and the sun:
        fieldWidth = 4e11;
        fieldDA = fieldWidth / (fieldCount-1); 
        obj1 = body(fieldDA*fieldCount/2,fieldDA*fieldCount/2, 1.9891e30, fieldDA*3, sphere)
        obj2 = body(fieldDA*fieldCount/2 + 1.5e11,fieldDA*fieldCount/2, 5.97e24, fieldDA*1, sphere, trail=False)
        
        
        #obj2.setVel(vec(sqrt(obj1.getMass()/mag(obj1.dist(obj2))) * 1,0,0));
        
        obj2.setVel(vec(0,0,-pi) * sqrt(obj1.getMass()/mag(obj1.dist(obj2)))) #our units are so messed up there's a division by pi somewhere :skull:
        
        #obj2.setVel(vec(0,0,-1) * sqrt(obj1.getMass()/mag(obj1.dist(obj2))))
        
        obj1.setColor(color.red);
        obj2.setColor(color.blue);
        
        Objects = [obj1, obj2]; 
        fieldFunction = gravityField;

    elif(val == 'Binary system'):
        #Binary star system:
        #This works as a demonstration of a shortcoming of this model, given these numbers the two stars should converge and reach a very large speed, 
        #but it just doesn't happen because the field is not precise enough when the two bodies are close
        fieldWidth = 8e11;
        fieldDA = fieldWidth / (fieldCount-1); 
        dist = 5e10
        obj1 = body(fieldWidth/2 - dist,fieldWidth/2 - dist, 2.78e31, fieldDA*3, sphere, trail=False)
        obj2 = body(fieldWidth/2 + dist,fieldWidth/2 + dist, 2.78e31, fieldDA*3, sphere, trail=False)
        #print(obj1.obj.pos);
        obj1.setVel(hat(vec(1, 0, -1)) * sqrt((obj2.getMass()+obj1.getMass())/mag(obj1.dist(obj2))) * 3*pi/5);
        obj2.setVel(hat(vec(-1, 0, 1)) * sqrt((obj2.getMass()+obj1.getMass())/mag(obj2.dist(obj1))) * 3*pi/5);
        
        
        Objects = [obj1, obj2];
        fieldFunction = gravityField;

    elif(val == 'Trinary system'):
        #Trinary star system: 
        fieldWidth = 8e11;
        fieldDA = fieldWidth / (fieldCount-1); 
        obj1 = body(fieldDA*fieldCount/2,   fieldDA*fieldCount/3, 1.9891e30, fieldDA*3, sphere)
        obj2 = body(fieldDA*fieldCount/2, fieldDA*2*fieldCount/3, 1.9891e30, fieldDA*3, sphere)
        obj3 = body(fieldDA*fieldCount/2,   fieldDA*fieldCount/2, 1.9891e30, fieldDA*3, sphere)
        
        obj1.setVel(vec(sqrt(obj3.getMass()/mag(obj1.dist(obj3)))*pi,0,0));
        obj2.setVel(vec(-sqrt(obj3.getMass()/mag(obj1.dist(obj3)))*pi,0,0));
        
        Objects = [obj1, obj2, obj3];
        fieldFunction = gravityField;

    elif(val == 'Binary + Planet'):
        fieldWidth = 8e11;
        fieldDA = fieldWidth / (fieldCount-1); 
        obj1 = body(fieldWidth/2 - 1e11/3, fieldWidth/2 - 1e11/3, 1e31, fieldDA*3, sphere, trail=False)
        obj2 = body(fieldWidth/2 + 1e11/3,fieldWidth/2 + 1e11/3, 1e31, fieldDA*3, sphere, trail=False)
        
        obj1.setVel(vec(sqrt(obj2.getMass()/mag(obj1.dist(obj2))),0,-sqrt(obj2.getMass()/mag(obj1.dist(obj2)))));
        obj2.setVel(vec(-sqrt(obj1.getMass()/mag(obj2.dist(obj1))),0,sqrt(obj2.getMass()/mag(obj1.dist(obj2)))));
        
        obj3 = body(fieldWidth/2 + fieldDA*fieldCount/4, fieldWidth/2 + fieldDA*fieldCount/4, 5e24, fieldDA*1, sphere, trail=False); 
        
        
        
        obj3.setVel(vec(-1, 0, 1) * sqrt((obj2.getMass() + obj1.getMass()) / mag(obj3.obj.pos-(obj2.obj.pos+obj1.obj.pos)))*pi);
        
        Objects = [obj1, obj2, obj3]; 
        fieldFunction = gravityField;
    elif(val == 'Orbital ring'):
        #Orbital ring (Saturn): 
        fieldWidth = 8e11;
        fieldDA = fieldWidth / (fieldCount-1); 
        bigObj = body(fieldWidth/2, fieldWidth/2, 4e32, fieldDA*2, sphere);
        bigObj.setColor(color.red);
        
        Objects.append(bigObj);
        
        objC = 64; 
        dTheta = 360/objC;
        for i in range(0, objC):
            #mass = ((random()*1.2+0.1)*1e31);
            mass = 1e29;
            #print((0.1+random()*0.8)*fieldWidth);
            #circPos = vec(cos(t), 0, sin(t)) * (0.1+random()*0.8)*fieldWidth; 
            circPos = vec(fieldWidth/2, 0, fieldWidth/2) + (vec(cos(radians(i*dTheta)), 0, sin(radians(i*dTheta))) * fieldWidth/8); 
            obj = body(circPos.x, circPos.z, mass, fieldDA*1, sphere); 
            obj.setVel(vec(-sin(radians(i*dTheta)), 0, cos(radians(i*dTheta))) * mag(circPos-vec(fieldWidth/2, 0, fieldWidth/2)) * pi/3);
            #obj.setVel(random() * obj.getMass() * vec(random()-0.5, 0, random()-0.5));
            #dist = obj.dist(bigObj); 
            #perp = hat(vec(dist.x, 0, -dist.z));
            #obj.setVel(perp*pi*(sqrt(bigObj.getMass()/mag(obj.dist(bigObj)))));
            
            Objects.append(obj); 
        fieldFunction = gravityField;

    elif(val == 'Syzygy'):
        #straight line 
        fieldWidth = 8e11;
        fieldDA = fieldWidth / (fieldCount-1); 
        bigObj = body(fieldWidth/2, fieldWidth/2, 8e31, fieldDA*2, sphere);
        bigObj.setColor(color.red);
         
        Objects.append(bigObj);
         
        numPlanets = 5
        objC = 64; 
        dTheta = 360/objC;
        for i in range(numPlanets):
            diff = -int(numPlanets/2) + i
            
            mass = 1e29;
            circPos = vec(fieldWidth/2, 0, fieldWidth/2) + vec(diff,0,0) * fieldWidth/8; 
            #print(circPos)
            obj = body(circPos.x, circPos.z, mass, fieldDA*1, sphere); 
            obj.setVel(vec(-sin(radians(i*dTheta)), 0, cos(radians(i*dTheta))) * mag(circPos-vec(fieldWidth/2, 0, fieldWidth/2)) * 1/2);
            Objects.append(obj);         
        fieldFunction = gravityField;

    elif(val == 'Random'):
        #random placement 
        fieldWidth = 8e11;
        fieldDA = fieldWidth / (fieldCount-1); 
        numPlanets = 5
        objC = 64; 
        dTheta = 360/objC;
        for i in range(numPlanets):
            mass = 1e30;
            circPos = vec(random()*fieldWidth, 0, random()*fieldWidth)
            #circPos.x += random(-fieldWidth/4, fieldWidth/4)
            #circPos.z += random(-fieldWidth/4, fieldWidth/4)
            obj = body(circPos.x, circPos.z, mass, fieldDA*1, sphere); 
            obj.setVel(vec(0,0,0))
            Objects.append(obj);    
        fieldFunction = gravityField;
        
    elif (val == "Carousel"):
        fieldWidth = 8e11;
        fieldDA = fieldWidth / (fieldCount-1); 
        #centObj = body(fieldWidth/2, fieldWidth/2, 8e31, fieldDA*2, sphere);
        centObj = body(fieldWidth/2, fieldWidth/2, 5e40, fieldDA*2, sphere, trail=False, mass2=0, fieldFunc=carouselField);
        Objects.append(centObj);
        numPlanets = 15
        objC = 64; 
        dTheta = 360/objC;
        for i in range(numPlanets):
            mass = 8e30;
            circPos = vec(fieldDA+random()*(fieldWidth-fieldDA*2), 0, fieldDA+random()*(fieldWidth-fieldDA*2))
            obj = body(circPos.x, circPos.z, mass, fieldDA*1, sphere); 
            obj.setVel(vec(0,0,0))
            Objects.append(obj);
    elif (val == "Cool swirly field (NOT GRAVITY)"):
        #print("a");
        fieldWidth = 8e12;
        fieldDA = fieldWidth / (fieldCount-1); 
        dist = 1e11/3
        #print("b");
        obj1 = body(fieldWidth/2 - dist, fieldWidth/2 - dist, 5e20, fieldDA, sphere, trail=False, mass2=3e19, fieldFunc=coolSwirlyField)
        obj2 = body(fieldWidth/2 + dist, fieldWidth/2 + dist, 5e20, fieldDA, sphere, trail=False, mass2=-3e19, fieldFunc=coolSwirlyField)
        #print("c");
        obj1.setVel(vec(1, 0, -1) * sqrt(1e31/mag(obj1.dist(obj2))));
        obj2.setVel(vec(1, 0, 1) * sqrt(1e31/mag(obj2.dist(obj1))));
 
        obj1.setColor(color.red);
        obj2.setColor(color.blue);
        
        Objects = [obj1, obj2]; 
        #print("que");
    elif (val == "Cool swirly field 2 (NOT GRAVITY)"):
        fieldWidth = 8e11;
        fieldDA = fieldWidth / (fieldCount-1); 
        dist = fieldWidth/3;
        partCount = 16;
        c = color.red;
        m = 3e19;
        #print("a");
        for i in range(0, partCount):
            if(random() > 0.5):
                c = color.red; 
                m = 3e19;
            else:
                c = color.blue;
                m = -3e19;
            #print("b");
            #obj = body(fieldWidth/2 - dist * (-1+random()*2), fieldWidth/2 - dist * (-1+random()*2), 5e20, fieldDA, sphere, trail=True, m)
            obj = body(fieldWidth/2 + dist * (-1+random()*2), fieldWidth/2 + dist * (-1+random()*2), 5e23, fieldDA/4, sphere, trail=False, mass2=m, fieldFunc=coolSwirlyField)
            obj.setColor(c); 
            obj.setVel(dist * vec(random()-0.5, 0, random()-0.5));
            Objects.append(obj);
            #print("c");
        #fieldFunction = magneticField;  
        #print("sus");

        
    for x in range(0, fieldCount):
        for y in range(0, fieldCount):
            field[x][y].visible = False;
    fieldDA = fieldWidth / (fieldCount-1); 
    downConstant = log10(fieldDA);
    field = [[arrow(pos=vec(y*fieldDA, 0, x*fieldDA)) for x in range(0, fieldCount)] for y in range(0, fieldCount)];
    zeroField(field);
    for o in Objects:
        o.impactField(field, v2pos, fieldFunction);
    #closedCurveIntegral();
    scene.center = vec(fieldWidth/2, 0, fieldWidth/2);
    normalizeField(field);
    #print(fieldWidth);
    for i in range(len(Objects)):
        c = gcurve(color=vector.random(), graph=DCvsT) 
        DCvsTC.append(c);
    t = 0 


v2pos = Vector2(0,0);
running = False; 
doFieldLines = False;

zeroField(field);
for o in Objects:
        o.impactField(field, v2pos);
        
normalizeField(field);

larr = [];
for i in range(0, 16):
    cols = vec(random()*0.5, random()*0.5, random()*0.5) + vec(0.5, 0.5, 0.5);
    l = EquipotentialLine(col=cols)
    larr.append(l);

while(1):
    rate(1000);    
    if(running):        
        
        
        zeroField(field);
        meanX = 0;
        meanY = 0;
        for o in Objects:
            o.impactField(field, v2pos);
            meanX += o.getX()/len(Objects);
            meanY += o.getY()/len(Objects);
           
        if(doFieldLines):
            runFieldLines();
        
        KE = 0;
        for o in Objects:
            o.applyForce(field);
            KE += 0.5 * (mag(o.obj.vel) ** 2) * (o.obj.mass);
        kePlot.plot(t, KE); 
        
        
        for i in range(len(Objects)):
            DCvsTC[i].plot(t,mag(Objects[i].obj.pos-vec(fieldWidth/2,0,fieldWidth/2)))
        
        normalizeField(field);
        t += dt;    