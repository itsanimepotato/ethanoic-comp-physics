from vpython import *
#Web VPython 3.2

class Vector2:
    def __init__(self, x, y):
        self.x = x;
        self.y = y;
    def __add__(self, other):
        self.x += other.x;
        self.y += other.y; 
        return self;
    def __subtract__(self, other):
        self.x -= other.x;
        self.y -= other.y;
        return self;    updateField(field, Vector2(fieldWidth/2,fieldWidth/2), 25);

    def __multiply__(self, other):
        self.x *= other;
        self.y *= other;
        return self;
    def setX(self, x):
        self.x = x;
    def setY(self, y):
        self.y = y;
    def clone(self):
        return Vector2(self.x, self.y);
    def magsq(self):
        return self.x*self.x + self.y*self.y;
    def mag(self):
        return sqrt(self.x*self.x + self.y*self.y);
    def distsq(self, other):
        return (self.x-other.x)*(self.x-other.x) + (self.y-other.y)*(self.y-other.y);
    def toString(self):
        return f"<{self.x}, {self.y}>"

fieldCount = 64; 
fieldWidth = 8 
fieldDA = fieldWidth / fieldCount; 
field = [[arrow(pos=vec(y*fieldDA, 0, x*fieldDA)) for x in range(0, fieldCount)] for y in range(0, fieldCount)];

G = 6.7e-11;
dt = 0.1; 

def printField(field):
    for x in range(0, fieldCount):
        for y in range(0, fieldCount):
            str = (field[x][y].axis)
            print(str, end=" ");
        print();

EPSILON = 1e-5

def zeroPoint(field, x, y):
    field[x][y].axis = vec(0,0,0);
    field[x][y].pos.y = 0;

def zeroField(field):
    for x in range(0, fieldCount):
        for y in range(0, fieldCount):
            zeroPoint(field, x, y);

#marker = arrow(size=vec(0.1,0.4,0.1), color=color.yellow); 

def updateField(field, v2pos, mass):
    for y in range(0, fieldCount):
        for x in range(0, fieldCount):
            p = vector(x*fieldDA, 0, y*fieldDA);
            #marker.pos = p;
            p.x -= v2pos.x;#*fieldDA;
            p.z -= v2pos.y;#*fieldDA;
            #marker.axis=-p;
            valMag = mag(p);
            #field[x][y].axis += -hat(p)*0.1; #-(fieldDA / (valMag)) * p ; #test jargon, this is not gravity. 
            if(valMag > fieldDA):        
                field[x][y].axis += -hat(p)*fieldDA;
                field[x][y].pos.y -= fieldDA/valMag; 

scene.append_to_title("<div id='fps'/>")

#obj = box(pos=vec(fieldWidth/2, fieldWidth/2, 0));

rate(60);
#printField(field); 
t = 0;
dt = 0.1;
floor = box(pos=vec(fieldWidth/2,0,fieldWidth/2), size=vec(fieldWidth, 0.1, fieldWidth), opacity=0.5);
ke = label(pos=vec(fieldWidth/2, fieldWidth, 0), text="sus");


obj1 = sphere(radius=fieldDA, color=color.blue);
obj2 = sphere(radius=fieldDA, color=color.red); 

obj2.pos=vec(1,0,1);
obj2.acc = vec(0,0,0);
obj2.vel = vec(0,0,0);

obj1.pos = vec(2,0,2);
obj1.acc = vec(0,0,0);
obj1.vel = vec(0.1,0,0);

v2pos = Vector2(0,0); 

class Obj:
    
    def __init__(self, p, v, a, m):
        self = sphere(pos=p,radius=fieldDA, color=vector.random())
        self.vel = v
        self.acc = a
        self.mass = m

objects = []

for i in range(5):
    global objects
    objects.append(Obj(vec(random(0,i),0,random(0,i)),vec(random(-0.1,0.1),0,0),vec(0,0,0),5))
    

while(1):
    rate(60);
    zeroField(field);
    v2pos.x = obj1.pos.x;
    v2pos.y = obj1.pos.z;
    updateField(field, v2pos, 5.97e24);
    v2pos.x = obj2.pos.x;
    v2pos.y = obj2.pos.z;
    updateField(field, v2pos, 5.97e24);
    #v2pos = Vector2(fieldWidth/2 + cos(t), fieldWidth/2 + sin(t))
    #obj1.pos.x = v2pos.x; 
    #obj1.pos.z = v2pos.y;
    ax = field[round(obj1.pos.x/fieldDA)][round(obj1.pos.z/fieldDA)];
    #marker.axis = ax.axis * 5;
    obj1.acc = ax.axis * 0.1 * -ax.pos.y/fieldDA; 
    obj1.vel += obj1.acc * dt; 
    obj1.pos += obj1.vel * dt;
    
    if(obj1.pos.x >= fieldWidth-fieldDA or obj1.pos.x < fieldDA or obj1.pos.z > fieldWidth-fieldDA or obj1.pos.z < fieldDA):
        obj1.vel *= -1; 
        obj1.pos += obj1.vel * dt * 2;
        
    

    
    #v2pos = Vector2(fieldWidth/2 + cos(2*t), fieldWidth/2 + sin(2*t))
    #marker.pos = obj2.pos; 
    ax = field[round(obj2.pos.x/fieldDA)][round(obj2.pos.z/fieldDA)];
    #marker.axis = ax.axis * 5;
    obj2.acc = ax.axis * 0.1 * -ax.pos.y/fieldDA; 
    obj2.vel += obj2.acc * dt; 
    obj2.pos += obj2.vel * dt;
    
    if(obj2.pos.x >= fieldWidth-fieldDA or obj2.pos.x < fieldDA or obj2.pos.z > fieldWidth-fieldDA or obj2.pos.z < fieldDA):
        obj2.vel *= -1; 
        obj2.pos += obj2.vel * dt * 2;
    v2pos.x = obj2.pos.x;

    
    ke.text = 0.5*(mag(obj2.vel)**2 + mag(obj1.vel)**2)
    
    #print("p: ", obj2.pos, "x: ", round(obj2.pos.x/fieldDA), "y: ", round(obj2.pos.z/fieldDA), "v: ", ax); 
    #obj2.pos.z += v2pos.y;
    #updateField(field, v2pos, 1.9891e30);
    
    
    
    t += 0.01;
